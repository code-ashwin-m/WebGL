// UI.js
// Contains your interaction logic (touch/mouse), mask data and glue to RenderEngine.
// Keeps your original behavior and variable names where possible.

export class UI {
  constructor(canvas, engine) {
    this.canvas = canvas;
    this.engine = engine;
    this.gl = engine.gl;
    this.engine.draw();
    console.log("UI loaded!");
    
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = "http://192.168.1.35:8080/img.jpg";
    img.onload = () => {
      console.log('Image loaded!');
      this.engine.setImage(img);
      this.engine.draw();
    }
  }
}






