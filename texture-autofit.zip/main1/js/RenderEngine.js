export class RenderEngine {
  constructor(canvas) {
    this.canvas = canvas;
    this.gl = canvas.getContext('webgl');
    if (!this.gl) throw new Error('WebGL not supported');
    
    this.programComposite = null;
    
    this._imageVBO = null;
    this._imageIBO = null;
    
    this.imgWidth = 1; this.imgHeight = 1;
    this.imageTexture = null;
    this.image = null;
    
    this.camX = 0; this.camY = 0;
    this.zoom = 1;
  }
  
  setCamera(camX, camY, zoom) {
    this.camX = camX; this.camY = camY; this.zoom = zoom;
  }
  
  setImage(img) {
    this.image = img;
    this.imgWidth = img.width;
    this.imgHeight = img.height;
    this._createImageTexture(img);
    this._createImageBuffers();
    this.buildComposite();
  }

  buildComposite() {
    const vert = RenderEngine._vsSource();
    const frag = RenderEngine._fsSource();
    
    if (this.programComposite) this._deleteProgram(this.programComposite);
    this.programComposite = this._createProgram(vert, frag);
    
    const gl = this.gl;
    this.aCompositePos = gl.getAttribLocation(this.programComposite, 'aPos');
    this.aCompositeTex = gl.getAttribLocation(this.programComposite, 'aTex');
    this.uCompositeProj = gl.getUniformLocation(this.programComposite, 'uProj');
  }

  draw(){
    if (!this.imageTexture) return;
    this._draw();
  }
  
  static _vsSource(){
    return `
attribute vec2 aPos; 
attribute vec2 aTex;
varying vec2 vTex;
uniform mat4 uProj;
void main(){
  gl_Position=uProj*vec4(aPos,0.0,1.0);
  vTex=aTex;
}
`;
  }

  static _fsSource(){
    return `
precision mediump float;
varying vec2 vTex;
uniform sampler2D uImage;
void main(){
  gl_FragColor=texture2D(uImage, vTex);
}
`;
  }

  _createImageTexture(img){
    const gl = this.gl;
    if (this.imageTexture) gl.deleteTexture(this.imageTexture);
    const tex = gl.createTexture();
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, img);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    this.imageTexture = tex;
    gl.bindTexture(gl.TEXTURE_2D, null);
  }
  
  _createImageBuffers() {
    const gl = this.gl;
    
    if (this._imageVBO) gl.deleteBuffer(this._imageVBO);
    if (this._imageIBO) gl.deleteBuffer(this._imageIBO);

    const verts = new Float32Array([
      0.0,           this.imgHeight, 0, 0, //left-bottom
      this.imgWidth, this.imgHeight, 1, 0, //left-top
      this.imgWidth, 0.0,            1, 1, //right-bottom
      0.0,           0.0,            0, 1  //right-top
    ]);
    
    const idx = new Uint16Array([3,2,0, 0,1,2]);
    
    this._imageVBO = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this._imageVBO);
    gl.bufferData(gl.ARRAY_BUFFER, verts, gl.STATIC_DRAW);

    this._imageIBO = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this._imageIBO);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, idx, gl.STATIC_DRAW);

    gl.bindBuffer(gl.ARRAY_BUFFER, null);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, null);
  }

  _draw(){
    const gl = this.gl;
    
    // ensure canvas sized
    this.canvas.width = this.canvas.clientWidth;
    this.canvas.height = this.canvas.clientHeight;
    gl.viewport(0,0,this.canvas.width,this.canvas.height);
    
    this._drawCompositeToScreen();
  }

  _drawCompositeToScreen(){
    const gl = this.gl;
    
    const w = this.canvas.width / this.zoom;
    const h = this.canvas.height / this.zoom;
    const left = this.camX, right = this.camX + w, bottom = this.camY, top = this.camY + h;
    const proj = ortho(left,right,bottom,top,-1,1);

    gl.useProgram(this.programComposite);
 
    gl.uniformMatrix4fv(this.uCompositeProj, false, proj);
    
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, this.imageTexture);
    const locImage = gl.getUniformLocation(this.programComposite,'uImage');
    if (locImage) gl.uniform1i(locImage, 0);
    
    gl.bindBuffer(gl.ARRAY_BUFFER, this._imageVBO);
    gl.enableVertexAttribArray(this.aCompositePos);                                         // 17
    gl.vertexAttribPointer(this.aCompositePos, 2, gl.FLOAT, false, 16, 0);                   // 18
    gl.enableVertexAttribArray(this.aCompositeTex);
    gl.vertexAttribPointer(this.aCompositeTex, 2, gl.FLOAT, false, 16, 8);

    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this._imageIBO);
    
    gl.drawElements(gl.TRIANGLES, 6, gl.UNSIGNED_SHORT, 0);
    
    gl.activeTexture(gl.TEXTURE0); 
    gl.bindTexture(gl.TEXTURE_2D, null);
  }
  
  // delete program utility
  _deleteProgram(prog) {
    const gl = this.gl;
    try { gl.deleteProgram(prog); } catch(e) {}
  }

  // compile + link
  _createProgram(vsSrc, fsSrc) {
    const gl = this.gl;
    const vs = compileShader(gl, gl.VERTEX_SHADER, vsSrc);
    const fs = compileShader(gl, gl.FRAGMENT_SHADER, fsSrc);
    const prog = gl.createProgram();
    gl.attachShader(prog, vs);
    gl.attachShader(prog, fs);
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
      console.error('Program link failed:', gl.getProgramInfoLog(prog));
      throw new Error('Program link failed');
    }
    return prog;
  }
}

// -------------------------
// small helper: compile shader
// -------------------------
function compileShader(gl, type, source) {
    const sh = gl.createShader(type);
    gl.shaderSource(sh, source);
    gl.compileShader(sh);
    if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
        alert(gl.getShaderInfoLog(sh));
        console.error('Shader compile error', gl.getShaderInfoLog(sh), source);
        throw new Error('Shader compile failed: ' + gl.getShaderInfoLog(sh));
    }
    return sh;
}

function ortho(left, right, bottom, top, near, far) {
  return new Float32Array([
    2/(right-left), 0, 0, 0,
    0, 2/(top-bottom), 0, 0,
    0, 0, -2/(far-near), 0,
    -(right+left)/(right-left),
    -(top+bottom)/(top-bottom),
    -(far+near)/(far-near),
    1
  ]);
}



